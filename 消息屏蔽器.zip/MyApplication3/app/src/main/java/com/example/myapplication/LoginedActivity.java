package com.example.myapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LoginedActivity extends AppCompatActivity implements View.OnClickListener {
    private Button start;
    private Button addFucked;
    private Button addNice;


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logined);


        start=findViewById(R.id.startButton);
        addFucked=findViewById(R.id.addFucked);
        addNice=findViewById(R.id.addNice);

        start.setOnClickListener(LoginedActivity.this);
        addFucked.setOnClickListener(LoginedActivity.this);
        addNice.setOnClickListener(LoginedActivity.this);

/*
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(LoginedActivity.this,started.class);
                startActivity(intent);
            }
        });
        addFucked.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(LoginedActivity.this,addFuckedActivity.class);
                startActivity(intent);
            }
        });
        addNice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(LoginedActivity.this,addNiceActivity.class);
                startActivity(intent);
            }
        });
*/
    }

    @Override
    public void onClick(View v) {

        switch(v.getId()){
            case R.id.addFucked :
                Intent intent1=new Intent(LoginedActivity.this,addFuckedActivity.class);
                startActivity(intent1);

             break;
            case R.id.addNice:
                Intent intent3=new Intent(LoginedActivity.this,addNiceActivity.class);
                startActivity(intent3);
                break;
            case R.id.startButton:
                Intent intent2=new Intent(LoginedActivity.this,started.class);
                startActivity(intent2);
                break;

        }


    }
}