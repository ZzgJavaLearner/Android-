package com.example.myapplication;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
@SuppressLint("OverrideAbstract")
public class NotificationMonitor extends NotificationListenerService {
  static  List<String> black=new ArrayList();
  static  List<String> white=new ArrayList();
    public void set() throws IOException {
        Log.e("找到了","找到了找到了找到了找到了找到了找到了0");
        //非白非黑不屏蔽
        //默认黑名单
        black.add("中宣部");
        black.add("消防");
        black.add("郑州市");
        black.add("电气火灾");
        black.add("市场监督");
        black.add("河南");
        black.add("中共");
        black.add("深圳");
        black.add("诈骗");
        black.add("系统");
        black.add("更新");
        black.add("安全");


        //创建文件对象
        File file = new File(getFilesDir(), "black.txt");
        System.out.println("找到了找到了找到了找到了找到了找到了找到了000");
//判断文件是否存在
        if (file.exists()) {
            System.out.println("找到了找到了找到了找到了找到了找到了找到了11111");
            //创建文件输入流
            FileInputStream fis = new FileInputStream(file);
            //创建缓冲读取器
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));
            //定义一个字符串变量用来存储每一行的文本
            String line = null;
            //循环读取每一行的文本，直到文件末尾
            while ((line = br.readLine()) != null) {
                //打印或处理每一行的文本
               black.add(line);
            }
            //关闭缓冲读取器和文件输入流
            br.close();
            fis.close();
        } else {
            //提示文件不存在
            System.out.println("没找到没找到没找到没找到没找到没找到没找到没找到没找到");
            Toast.makeText(this, "文件不存在", Toast.LENGTH_SHORT).show();
        }

        //默认白名单
        white.add("验证码");
        white.add("余额");
        white.add("菜鸟");
        white.add("包裹");

    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)


    @Override
    public void onCreate() {

        super.onCreate();
        ComponentName cn = new ComponentName(this, NotificationMonitor.class);


        String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        final boolean enabled = flat != null && flat.contains(cn.flattenToString());
        if (!enabled) {
            //Show a dialog to ask user to enable notification access
            Intent intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            startActivity(intent);
        }
        toggleNotificationListenerService();
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @SuppressLint({"LongLogTag", "NewApi"})
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            set();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Notification notify=sbn.getNotification();
        Bundle extras=notify.extras;
        String title=extras.getString(Notification.EXTRA_TITLE);
        String text=extras.getString(Notification.EXTRA_TEXT);
            
            if (isFucked(title, text)) {
                cancelNotification(sbn.getKey());
            }
        toggleNotificationListenerService();
    }
    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        Log.i("有消息被删除啦   啊啊啊","dawdasw");
    }
    @RequiresApi(api = Build.VERSION_CODES.M)
    public Boolean isFucked(String title, String text){
        new temp();
        int length1=white.size();
        int length2=black.size();
        for(int i=0;i<length2;i++){
            if(title.contains(black.get(i))){
                return true;
            }
        }
        for(int i=0;i<length1;i++){
            if(text.contains(white.get(i))){
                return false;
            }
        }
        for(int i=0;i<length2;i++){
            if(text.contains(black.get(i))){
                return true;
            }
        }

        return false;
    }
    public boolean ai(){
        return true;
    }

    void toggleNotificationListenerService() {
        PackageManager pm = getPackageManager();
        pm.setComponentEnabledSetting(new ComponentName(this, com.example.myapplication.NotificationMonitor.class),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);

        pm.setComponentEnabledSetting(new ComponentName(this, com.example.myapplication.NotificationMonitor.class),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);

    }
    @Override
    public IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }

}
