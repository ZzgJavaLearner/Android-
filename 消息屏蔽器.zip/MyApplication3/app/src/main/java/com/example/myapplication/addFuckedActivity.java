package com.example.myapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;


public class addFuckedActivity extends AppCompatActivity {
    private Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_fucked);
        b1=findViewById(R.id.blackSave);
    }

    @SuppressLint("ResourceType")
    @RequiresApi(api = Build.VERSION_CODES.M)
    public void second(View v) throws IOException {
    if(v.getId()==R.id.blackSave){
        TextView t=findViewById(R.id.blackText);
        FileOutputStream fos= null;
        File file=new File(getFilesDir(),"black.txt");
            try {
                if(file.exists()) {
                    //打开文件输出流
                     fos = new FileOutputStream(file, true);
                    //写入数据
                    fos.write((t.getText().toString() + "\r\n").getBytes());
                    //关闭输出流
                    fos.close();

                }
                else{
                    file.createNewFile();
                }
        }catch(Exception e){
            e.printStackTrace();
        }
        t.setText("");
        Intent intent=new Intent(this,SucessSave.class);
        startActivity(intent);
    }
    }

}