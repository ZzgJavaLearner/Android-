package com.example.myapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class addNiceActivity extends AppCompatActivity {
    private Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        b=findViewById(R.id.whiteSave);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_nice);
    }
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    public void first(View v) throws IOException {
        if(v.getId()==R.id.whiteSave){
            TextView t=findViewById(R.id.whiteText);
//获取内部存储的路径
            String path = getFilesDir().getAbsolutePath();
//创建文件对象
            File file = new File(path,"whiteList.txt");
            file.mkdirs();
            if(!file.exists()){
                file.createNewFile();
            }
//创建输出流对象
            FileOutputStream fos = new FileOutputStream(file,true);
//写入数据
            fos.write((t.getText().toString()+"\r\n").getBytes());
//关闭输出流
            fos.close();
            t.setText("");
            Intent intent=new Intent(this,SuccessSave2.class);
            startActivity(intent);
        }
    }

}